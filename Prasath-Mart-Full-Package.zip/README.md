# Prasath Mart
A starter electronics shopping website.

## Run
Open `index.html` in a browser.

## Included
Login, registration, home, products, cart, checkout, orders, profile and admin starter pages.

## Note
This version uses browser localStorage for demo authentication/cart/orders. The SQL file is a starter schema for a future backend connection.
